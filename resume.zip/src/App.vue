<template>
  <div id="app" style>
    <router-view/>
    <!-- <Index/> -->
  </div>
</template>

<script>
// import Index from "./view/index/Index.vue";

// export default {
//   name: "app",
//   components: {
//     Index
//   }
// };
</script>


