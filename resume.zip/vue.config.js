module.exports = {
    publicPath: './',
    // resolve: {
    //     extensions: ['.js', '.vue'],
    //     alias: {
    //         'vue$': 'vue/dist/vue.common.js'
    //     }
    // }
    // chainWebpack: config => {
    //         .rule('svg')
    //         .test(/\.svg$/)
    //         .include
    //         .add(resolve('src/icons'))
    //         .end()
    //         .use('svg-sprite-loader')
    //         .loader('svg-sprite-loader')
    //         .options({

    //         })
    // }
}